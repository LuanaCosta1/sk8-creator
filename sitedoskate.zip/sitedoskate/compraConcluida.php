<?php 
    $id_Compra = isset($_GET['id_Compra']) ? addslashes(trim($_GET['id_Compra'])) : false;
   
    session_start();

    $rodaEscolhida = isset($_SESSION['rodaEscolhida']) ? $_SESSION['rodaEscolhida'] : null;
    $shapeEscolhido = isset($_SESSION['shapeEscolhido']) ? $_SESSION['shapeEscolhido'] : null;
    $truckEscolhida = isset($_SESSION['truckEscolhida']) ? $_SESSION['truckEscolhida'] : null;
    $rolamentoEscolhida = isset($_SESSION['rolamentoEscolhida']) ? $_SESSION['rolamentoEscolhida'] : null;
    $lixaEscolhida = isset($_SESSION['lixaEscolhida']) ? $_SESSION['lixaEscolhida'] : null;
    $PecasAdd = isset($_SESSION['PecasAdd']) ? $_SESSION['PecasAdd'] : null;
    $valorFinalPecas = isset($_SESSION['valorFinalPecas']) ? $_SESSION['valorFinalPecas'] : null;
    
    // Restaurar a exibição de erros
    error_reporting(E_ALL);
    if ($rodaEscolhida === null || $shapeEscolhido === null || $truckEscolhida === null || $rolamentoEscolhida === null || $lixaEscolhida === null || $PecasAdd === null || $valorFinalPecas === null) {
        echo "Sua sessão pode ter expirado ou houve um problema. Por favor, volte para o início e entre em contato com o suporte.";
    
        echo '<br><a href="simulaSkate.php" class="btn btn-danger">Sair e Voltar para o Início</a>';
        exit;
    }
    

?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Bootstrap && CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="sytle.css" >
    <title>Compra Concluída</title>
</head>
<body>
    <div class='container'>

        <div class='containerCompraConcluida' id='containerCompraConcluida'>
            <div class='imprimirTela'>
                <img src='imagem/imprimir.png' alt='imprimir' onclick="printPage()">
            </div>
            <h1>Obrigado por Comprar</h1>
            <hr>
            <h2>Dados da Compra</h2>

            <div class='numeroPedido'>
                Numero do Pedido:  <b><?php echo"$id_Compra"; ?></b> 
            </div>
            <table>
                <tr>
                    <th width='40px'></th>
                    <th>Item</th>
                    <th>Descrição</th>
                </tr>
                <?php
                $itensComprados = array(
                    'Roda' => $rodaEscolhida,
                    'Shape' => $shapeEscolhido,
                    'Truck' => $truckEscolhida,
                    'Rolamento' => $rolamentoEscolhida,
                    'Lixa' => $lixaEscolhida,
                    'PecasAdd' => $PecasAdd,
                );

                foreach ($itensComprados as $nomeItem => $valorItem) {
                    echo "
                        <tr>
                            <td> <img style='width: 22px;' src='imagem/$nomeItem.png'></td>
                            <td><strong>$nomeItem</strong></td>
                            <td>$valorItem</td>
                        </tr>";
                }

                // Exiba o valor final das peças
                echo "
                <tr height='40px'></tr>
                    <tr>
                    <td></td>
                        <td><strong>Valor Total das Peças</strong></td>
                        <td>$valorFinalPecas</td>
                    </tr>";
                ?>
            </table>

            <form method="post" id='meuFormulario' action="simulaSkate.php">
                <button type="submit" class="btn btn-danger">Sair e Voltar para o Início</button>
            </form>
         </div>
    </div>


<!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script>

    function printPage() {
        window.print();
        }
    </script>
</body>
</html>