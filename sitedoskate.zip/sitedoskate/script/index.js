document.addEventListener("DOMContentLoaded", function() {

    document.getElementById("avancarPerguntas").addEventListener("click", function () {

        

        if(validaValores() == true){
            document.getElementById("containerPerguntas").style.display = "none";
            document.getElementById("containerMontagem").style.display = "block";
        }

    });

    document.getElementById("voltarPerguntas").addEventListener("click", function () {
        document.getElementById("containerPerguntas").style.display = "block";
        document.getElementById("containerMontagem").style.display = "none";
    });

    document.getElementById("avancarPecasAdd").addEventListener("click", function () {
        document.getElementById("containerMontagem").style.display = "none";
        document.getElementById("containerPecasAdd").style.display = "block";
    });

    document.getElementById("voltarMontagem").addEventListener("click", function () {
        document.getElementById("containerMontagem").style.display = "block";
        document.getElementById("containerPecasAdd").style.display = "none";
    });

    document.getElementById("avancarInformacaoFinal").addEventListener("click", function () {
        document.getElementById("containerInformacaoFinal").style.display = "block";
        document.getElementById("containerPecasAdd").style.display = "none";
        precoFinal();
    });

    document.getElementById("voltarPecasAdd").addEventListener("click", function () {
        document.getElementById("containerInformacaoFinal").style.display = "none";
        document.getElementById("containerPecasAdd").style.display = "block";
    });

    document.getElementById("avancarPagamento").addEventListener("click", function () {
        document.getElementById("containerInformacaoFinal").style.display = "none";
        document.getElementById("containerPagamento").style.display = "block";

    });

    document.getElementById("voltarPagamento").addEventListener("click", function () {
        document.getElementById("containerInformacaoFinal").style.display = "block";
        document.getElementById("containerPagamento").style.display = "none";
    });

    document.getElementById("btnPagar").addEventListener("click", function () {
        // Mostrar o modal de carregamento
        $('#loadingModal').modal('show');
      
        // Definir o valor inicial da barra de progresso
        let progress = 0;
        const progressBar = document.getElementById("loadingProgressBar");
      
        // Define o tempo em milissegundos para redirecionar (10 segundos no exemplo)
        const redirectTime = 10000; // 10 segundos
      
        // Função para aumentar a barra de progresso até 100% ou até o tempo de redirecionamento
        function increaseProgressBar() {
          if (progress < 100) {
            progress += 1;
            progressBar.style.width = progress + "%";
            progressBar.setAttribute("aria-valuenow", progress);
            requestAnimationFrame(increaseProgressBar);
          }
      
          // Verifique se o tempo de redirecionamento foi atingido
          if (progress >= 100) { // Agora vai verificar quando atingir 100%
            setTimeout(() => {
              $('#loadingModal').modal('hide');
              document.getElementById('meuFormulario').submit(); 
            }, redirectTime);
          }
        }
      
        // Inicie o aumento da barra de progresso
        increaseProgressBar();
      });
      
      
      
      
     function validaValores(){
        var error = 0;
	    var error_message = "Erro no processamento, efetue as seguintes correções:\n\n";
        
        var  peso = document.getElementById('Peso').value;
        var  Sapato = document.getElementById('Sapato').value;
        var  Altura = document.getElementById('Altura').value;
        
        if(peso == '' || peso < 10  ){
            error_message = error_message + "O peso de " + peso + " deve ser informado e ser acima de 10 quilos.\n";
            error = 1;
        }

        if(peso > 120  ){
            error_message = error_message + "O peso de" + peso + " infelizmente é acima do permitido.\n";
            error = 1;
        }
        if(Sapato == '' ){
            error_message = error_message + "O sapato deve ser informado.\n";
            error = 1;
        }

        if(Altura == '' || Altura < 1.00 ){
            error_message = error_message + "A altura " + Altura + " não é valida.\n";
            error = 1;
        }
        if(Altura > 2.30){
            error_message = error_message + "A altura " + Altura + " infelizmente é acima do permitido.\n";
            error = 1;
        }

        
        if (error == 1) {
            alert(error_message);
            return false;
          } else {
            return true;
        }
     } 


    // Obtenha os elementos select e o campo de entrada de texto
    const selectRoda = document.getElementById('selectRoda');
    const selectShape = document.getElementById('selectShape');
    const selectTruck = document.getElementById('selectTruck');
    const selectRolamento = document.getElementById('selectRolamento');
    const selectLixa = document.getElementById('selectLixa');
    const valorPecas = document.getElementById('valorPecas');

    // Defina um evento de mudança para ambos os selects
    selectRoda.addEventListener('change', calcularValorFinal);
    selectShape.addEventListener('change', calcularValorFinal);
    selectTruck.addEventListener('change', calcularValorFinal);
    selectRolamento.addEventListener('change', calcularValorFinal);
    selectLixa.addEventListener('change', calcularValorFinal);
    //selectLixa.addEventListener('change', calcularValorFinal);

    function calcularValorFinal() {
        // Remova os pontos de milhar e substitua a vírgula decimal por ponto
        const valorRoda = parseFloat(selectRoda.value.replace(/\./g, '').replace(',', '.'));
        const valorShape = parseFloat(selectShape.value.replace(/\./g, '').replace(',', '.'));
        const valorTruck = parseFloat(selectTruck.value.replace(/\./g, '').replace(',', '.'));
        const valorRolamento = parseFloat(selectRolamento.value.replace(/\./g, '').replace(',', '.'));
        const valorLixa = parseFloat(selectLixa.value.replace(/\./g, '').replace(',', '.'));
       // const valorLixa = parseFloat(selectLixa.value.replace(/\./g, '').replace(',', '.'));
    
        // Verifique se os valores são números válidos

            const valorFinal = valorRoda + valorShape + valorTruck + valorRolamento + valorLixa ;
    
            // Formate o valor usando a notação brasileira
            valorPecas.value = `${valorFinal.toLocaleString('pt-BR', {
                style: 'currency',
                currency: 'BRL',
                minimumFractionDigits: 2
            })}`;
    }
    calcularValorFinal();




    
});

function formatarNumero(input) {
    var valor = input.value.replace(/[^\d.]/g, '');
    valor = valor.replace(',', '');
    
    if (valor !== '') {
        var numero = parseFloat(valor);
        valor = (numero / 100).toFixed(2);
    }

    input.value = valor;
}


function precoFinal() {
    var selectRoda = document.getElementById("selectRoda");
    var selectShape = document.getElementById("selectShape");
    var selectTruck = document.getElementById("selectTruck");
    var selectRolamento = document.getElementById("selectRolamento");
    var selectLixa = document.getElementById("selectLixa");

    var rodaEscolhidaInput = document.getElementById('rodaEscolhida');
    var shapeEscolhidoInput = document.getElementById('shapeEscolhido');
    var truckEscolhidoInput = document.getElementById('truckEscolhida');
    var rolamentoEscolhidoInput = document.getElementById('rolamentoEscolhida');
    var lixaEscolhidoInput = document.getElementById('lixaEscolhida');


    var textoRoda = selectRoda.options[selectRoda.selectedIndex].text;
    var textoShape = selectShape.options[selectShape.selectedIndex].text;
    var textoTruck = selectTruck.options[selectTruck.selectedIndex].text;
    var textoRolamento = selectRolamento.options[selectRolamento.selectedIndex].text;
    var textoLixa = selectLixa.options[selectLixa.selectedIndex].text;

    // Defina os valores nos campos de input
    rodaEscolhidaInput.value = textoRoda;
    shapeEscolhidoInput.value = textoShape;
    truckEscolhidoInput.value = textoTruck;
    rolamentoEscolhidoInput.value = textoRolamento;
    lixaEscolhidoInput.value = textoLixa;


    var checkboxes = document.getElementsByName("pecas");
    var selecionados = [];
    var valorTotal = 0; // Variável para armazenar o valor total

    for (var i = 0; i < checkboxes.length; i++) {
        if (checkboxes[i].checked) {
            var valueParts = checkboxes[i].value.split(" @ ");
            var nome = valueParts[0];
            var valor = parseFloat(valueParts[1].replace(/\./g, '').replace(',', '.')); // Converter o valor para um número
            selecionados.push({ nome, valor });
            valorTotal += valor; // Adicionar o valor ao total
        }
    }

    if (selecionados.length > 0) {
        var textoSelecionados = selecionados.map(function(item) {
            return item.nome + " (R$: " + item.valor + ")";
        }).join("\n");

        var inputPecasAdd = document.getElementById('PecasAdd');
        inputPecasAdd.value = textoSelecionados;
    } else {
        document.getElementById('PecasAdd').value = '';
    }

    // Pega os valores da roda e shape e converte para números
    const valorRoda = parseFloat(selectRoda.value.replace(/\./g, '').replace(',', '.'));
    const valorShape = parseFloat(selectShape.value.replace(/\./g, '').replace(',', '.'));
    const valorTruck = parseFloat(selectTruck.value.replace(/\./g, '').replace(',', '.'));
    const valorRolamento = parseFloat(selectRolamento.value.replace(/\./g, '').replace(',', '.'));
    const valorLixa = parseFloat(selectLixa.value.replace(/\./g, '').replace(',', '.'));

    // Some todos os valores juntos
    const valorFinal = valorTotal + valorRoda + valorShape + valorTruck + valorRolamento + valorLixa;

    // Insira o valor final no elemento com o ID 'valorPecas'
    var inputValorPecas = document.getElementById('valorFinalPecas');
    inputValorPecas.value = 'R$: ' + valorFinal.toLocaleString('pt-BR', { minimumFractionDigits: 2 });






}


