<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="login.css">
</head>
<body>
    <header>
        <a href="index.html">SK8 Creator</a>
    </header>
    <main>
        <div class="form-login">
            <p class="title">Cadastro</p>
            <form action="signin.php" method="post">
                <label for="email">Email:</label>
                <input placeholder="Digite aqui seu e-mail" type="email" id="email" name="email" required>
        
                <label for="senha">Senha:</label>
                <input placeholder="Digite aqui sua senha" type="password" id="senha" name="senha" required>

                <label for="senha">Confirmar Senha:</label>
                <input placeholder="Confirme sua senha" type="password" id="senha" name="senha" required>
                <span class="form-link">Já tem conta? <a href="login.html">Entrar</a></span>
        
                <a href="cadastro.php" class="login-button">Cadastrar</a>
            </form>
        </div>
    </main>
</body>
</html>