<?php
require_once 'Banco_de_dados/conectaBanco.php';

session_start();
session_destroy();
session_start();
$categoria = '';
if($_POST){
 
    $respostacadastro = isset($_GET['respostacadastro']) ? addslashes(trim($_GET['respostacadastro'])) : false;

    $rodaEscolhida = isset($_POST['rodaEscolhida']) ? addslashes(trim($_POST['rodaEscolhida'])):FALSE;
    $shapeEscolhido = isset($_POST['shapeEscolhido']) ? addslashes(trim($_POST['shapeEscolhido'])):FALSE;
    $truckEscolhida = isset($_POST['truckEscolhida']) ? addslashes(trim($_POST['truckEscolhida'])):FALSE;
    $rolamentoEscolhida = isset($_POST['rolamentoEscolhida']) ? addslashes(trim($_POST['rolamentoEscolhida'])):FALSE;
    $lixaEscolhida = isset($_POST['lixaEscolhida']) ? addslashes(trim($_POST['lixaEscolhida'])):FALSE;
    $PecasAdd = isset($_POST['PecasAdd']) ? addslashes(trim($_POST['PecasAdd'])):FALSE;
    $valorFinalPecas = isset($_POST['valorFinalPecas']) ? addslashes(trim($_POST['valorFinalPecas'])):FALSE;

    $_SESSION['rodaEscolhida'] = $rodaEscolhida;
    $_SESSION['shapeEscolhido'] = $shapeEscolhido;
    $_SESSION['truckEscolhida'] = $truckEscolhida;
    $_SESSION['rolamentoEscolhida'] = $rolamentoEscolhida;
    $_SESSION['lixaEscolhida'] = $lixaEscolhida;
    $_SESSION['PecasAdd'] = $PecasAdd;
    $_SESSION['valorFinalPecas'] = $valorFinalPecas;


    function generateRandomString($length = 5) {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, strlen($characters) - 1)];
        }
    
        $currentDate = date("Ymd"); // Obtém a data atual no formato YYYYMMDD
        $randomString .= $currentDate;
    
        return $randomString;
    }
    
    $id_compra = generateRandomString(5);

    //insere dados na tabela do banco de dados
       $SQL1 = "INSERT INTO Produto (
            id_vinculo,
            id_compra,
            rodaEscolhida,
            shapeEscolhido,
            truckEscolhido,
            rolamentoEscolhido,
            lixaEscolhida,
            PecasAdd,
            valorFinalPecas
        ) VALUES (
            '$id_vinculo',
             $id_compra,
            '$rodaEscolhida',
            '$shapeEscolhido',
            '$truckEscolhido',
            '$rolamentoEscolhido',
            '$lixaEscolhida',
            '$PecasAdd',
            '$valorFinalPecas'
        )";

        //echo"$SQL1 <Br>";
      //  $rs1 = @mysqli_query($linkDB,$SQL1) or die("Erro no banco de dados_funcaoSQL1!"); 
      

     //direciona para pagina com a resposta da ação
    echo (" <script language='javascript'> parent.location.href = 'compraConcluida.php?id_Compra=$id_compra'</script>");

}



?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Bootstrap && CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="sytle.css" >

    <title>Monte seu Skate</title>
</head>
<body>
    <div class='container' >
            <form method="post" id='meuFormulario' action="simulaSkate.php">
                <div class='containerPerguntas' id='containerPerguntas'>
                    <h2>Preencha seus dados</h2>
                    <div class='wrapper'>
                        <div class='imagem'>
                            <img src='imagem/skate.png' alt='skate'>
                        </div>
                        <div class='conteudo'>
                            <div class='divPerguntas'>
                                <span><img style='width: 22px;' src='imagem/Peso.png'> Peso</span><br>
                                <input type='number' class='perguntas' id='Peso' placeholder='Peso'><br><br>

                                <span><img style='width: 22px;margin-top: -12px;' src='imagem/tamanhoPe.png'> Tamanho de pé</span><br>
                                <select class='perguntas' id='Sapato'>
                                    <option value=''>Selecione</option>
                                    <?php
                                        for ($i = 34; $i <= 48; $i++) {
                                            echo "<option value='$i'>$i</option>";
                                        }
                                    ?>
                                </select><br><br>

                                <span><img style='width: 22px;' src='imagem/Altura.png'> Altura (Ex: 122 cm)</span><br>
                                <input type='text' id='Altura' class='perguntas' placeholder='Altura' onblur='formatarNumero(this)'><br><br>

                            </div>
                        </div>
                    </div>
                    <div class='divBtn'>
                         <a href="index.html" class="btn btn-primary btn-voltar">Voltar para o site</a>

                        <button class="btn btn-primary btn-avancar" id="avancarPerguntas" type="button">Avançar</button>
                    </div> 
                </div>
                <div class='containerMontagem' id='containerMontagem' style="display: none;">
                    <h2>Monte seu skate </h2>
                    <div class='wrapper'>
                        <div class='imagem'>
                            <img src='imagem/skate.png' alt='skate'>
                        </div>
                        <div class='conteudo'>
                            <div class='divPerguntas'>
                                <div class='divProdutos'>
                                    <span><img style='width: 22px;' src='imagem/Roda.png'> Roda: </span><br>
                                    <select class='perguntas' name="roda" id="selectRoda">
                                        <?php
                                        $roda_precos = array(
                                            "12,00" => "35mm - Preço: R$12,00",
                                            "10,50" => "34mm - Preço: R$10,50",
                                            "14,00" => "36mm - Preço: R$14,00"
                                        );

                                        foreach ($roda_precos as $valor => $descricao) {
                                            echo "<option value='$valor'>$descricao</option>";
                                        }
                                        ?>
                                    </select><br><br>

                                    <span><img style='width: 22px;' src='imagem/Shape.png'> Shape: </span><br>
                                    <select class='perguntas' id="selectShape">
                                        <?php
                                        $shapes_precos = array(
                                            "249,00" => "Shape Element Maple Section - Preço: R$ 249,00",
                                            "219,50" => "Shape Santa Cruz Powerlyte - Preço: R$ 219,50",
                                            "240,50" => "SHAPE ELEMENT MAPLE  - Preço: R$ 240,50"
                                        );

                                        foreach ($shapes_precos as $valor => $descricao) {
                                            echo "<option value='$valor'>$descricao</option>";
                                        }
                                        ?>
                                    </select><br><br>

                                    <span><img style='width: 22px;' src='imagem/Truck.png'> Truck : </span><br>
                                    <select class='perguntas' id="selectTruck">
                                        <?php
                                        $shapes_truck = array(
                                            "189,00" => "Truck Essência 139mm - Preço: R$ 189,00",
                                            "99,00" => "Truck de Skate iniciante 139mm - Preço: R$ 99,00",
                                            "319,90" => "Truck Level 139mm Italo - Preço: R$ 319,90"
                                        );

                                        foreach ($shapes_truck as $valor => $descricao) {
                                            echo "<option value='$valor'>$descricao</option>";
                                        }
                                        ?>
                                    </select><br><br>

                                    <span><img style='width: 22px;' src='imagem/Rolamento.png'> Rolamento : </span><br>
                                    <select class='perguntas' id="selectRolamento">
                                        <?php
                                        $shapes_rolamento = array(
                                            "49,90" => "Rolamento BLACK SHEEP RED - Preço: R$ 49,90",
                                            "199,00" => "Rolamento RED BONES - Preço: R$ 199,00",
                                            "69,90" => "Rolamento BLACK SHEEP GOLD - Preço: R$ 69,90"
                                        );

                                        foreach ($shapes_rolamento as $valor => $descricao) {
                                            echo "<option value='$valor'>$descricao</option>";
                                        }
                                        ?>
                                    </select><br><br>

                                    <span><img style='width: 22px;' src='imagem/Lixa.png'> Lixa : </span><br>
                                    <select class='perguntas' id="selectLixa">
                                        <?php
                                        $shapes_lixa = array(
                                            "29,90" => "Lixa Emborrachada - Preço: R$ 29,90",
                                            "14,90" => "Lixa Para Skate Nacional - Preço: R$ 14,90",
                                            "39,90" => "Lixa Importada Visible Emborrachada - Preço: R$ 39,90"
                                        );

                                        foreach ($shapes_lixa as $valor => $descricao) {
                                            echo "<option value='$valor'>$descricao</option>";
                                        }
                                        ?>
                                    </select><br><br>

                                    <span> <img style='width: 22px;' src='imagem/Preco.png'> Preço Total: </span><br>
                                    <input type='text' class='perguntas' readonly value='' id='valorPecas'>
                                </div>
                            </div>
                        </div>
                    </div>
                    <br><br>
                    <div class='divBtn'>
                        <button class="btn btn-primary btn-voltar" id="voltarPerguntas"  type="button">Voltar</button>
                        <button class="btn btn-primary btn-avancar" id="avancarPecasAdd"  type="button">Avançar</button>                  
                    </div>
                </div>

                <div class='containerPecasAdd' id='containerPecasAdd' style="display: none;">

                    <h2>Escolha itens adicionais </h2>

                    <div class='boxPecas'> 
                        <div class='pecasAdd'>
                            <input type="checkbox" id="peca1" name="pecas" value="Vela @ 28,90">
                            <label for="peca1">Vela</label>
                        </div> 

                        <div class='pecasAdd'>
                            <input type="checkbox" id="peca2" name="pecas" value="Capacete @ 198,00">
                            <label for="peca2">Capacete</label>
                        </div> 

                        <div class='pecasAdd'>
                            <input type="checkbox" id="peca3" name="pecas" value="Cotoveleira @ 120,00">
                            <label for="peca3">Cotoveleira</label>
                        </div> 
                        
                        <div class='pecasAdd'>
                            <input type="checkbox" id="peca4" name="pecas" value="joelheira @ 79,90">
                            <label for="peca4">Joelheira</label>
                        </div> 

                        <div class='pecasAdd'>
                            <input type="checkbox" id="peca5" name="pecas" value="Protetor de pulso @ 160,90">
                            <label for="peca5">Protetor de pulso</label>
                        </div> 

                        <div class='pecasAdd'>
                            <input type="checkbox" id="peca6" name="pecas" value="Chave T @ 19,90">
                            <label for="peca6">Chave T</label>
                        </div> 
                    </div>

                
                    <br><br>
                    <div class='divBtn'>
                        <button class="btn btn-primary btn-voltar" id="voltarMontagem"  type="button">Voltar</button>
                        <button class="btn btn-primary btn-avancar" id="avancarInformacaoFinal"  type="button">Avançar</button>                  
                    </div>
                </div>


                <div class='containerInformacaoFinal' id='containerInformacaoFinal' style="display: none;">
                    <h2>Skate Montado</h2>
                    <div class='wrapper'>
                        <div class='imagem'>
                            <img src='imagem/skate.png' alt='skate'>
                        </div>
                        <div class='conteudo'>
                            <div class='divPerguntas'>
                                <div class='divProdutos'>
                                    <img style='width: 22px;' src='imagem/Roda.png'> Roda:<br>
                                    <input type='text' class='perguntas' readonly name='rodaEscolhida'  id='rodaEscolhida'><br><br>
                                    
                                    <img style='width: 22px;' src='imagem/Shape.png'> Shape:<br>
                                    <input type='text' class='perguntas' readonly name='shapeEscolhido'  id='shapeEscolhido'><br><br>
                                    
                                    <img style='width: 22px;' src='imagem/Truck.png'> Truck :<br>
                                    <input type='text' class='perguntas' readonly name='truckEscolhida'   id='truckEscolhida'><br><br>
                                    
                                    <img style='width: 22px;' src='imagem/Rolamento.png'> Rolamento :<br>
                                    <input type='text' class='perguntas' readonly name='rolamentoEscolhida'  id='rolamentoEscolhida'><br><br>
                                    
                                    <img style='width: 22px;' src='imagem/Lixa.png'> Lixa :<br>
                                    <input type='text' class='perguntas' readonly name='lixaEscolhida'  id='lixaEscolhida'><br><br>
                                    
                                    <img style='width: 22px;' src='imagem/PecasAdd.png'> Item adicionais:<br>
                                    <textarea class='perguntas' readonly name='PecasAdd'  id='PecasAdd' ></textarea><br><br>

                                    <span> <img style='width: 22px;' src='imagem/Preco.png'> Preço Total: </span><br>
                                    <input type='text' class='perguntas' name='valorFinalPecas'  readonly value='' id='valorFinalPecas'>
                                </div>
                            </div>
                        </div>
                
                    </div>
                    <br><br>
                    <div class='divBtn'>
                        <button class="btn btn-primary btn-voltar" id="voltarPecasAdd"  type="button">Voltar</button>
                        <button class="btn btn-primary btn-avancar" id="avancarPagamento"  type="button">Pagar</button>                  
                    </div>
                </div>

                <div class='containerPagamento' id='containerPagamento' style="display: none;">

                <div class='pagamento'>
                    <div class='pagamentoPix'>
                        <span>Pagamento pix, boleto, cartão de credito.</span>
                    </div>

                    <div class='btnPagamento' id='btnPagar'>
                        <span>Comprar</span>
                    </div>
                                        
                </div>
                

                    <div class='divBtn'>
                        <button class="btn btn-primary btn-voltar" id="voltarPagamento"  type="button">Voltar</button>
                    </div>  
                </div>
            </form>
            <div class="modal" id="loadingModal" tabindex="-1" role="dialog" data-backdrop="static">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-body">
                        <div class="progress">
                            <div class="progress-bar" id="loadingProgressBar" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                        <p>Carregando...</p>
                    </div>
                </div>
            </div>
        </div>








<!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script src="script/index.js"></script>
    
</body>
</html>