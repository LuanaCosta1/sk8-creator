<?php 

if($_POST){
  $resposta = "Produto salvo com Sucesso! Codigo do produto: Jf7HkRtZs2D6pQ";

  $divProduto = "display:block;";
        
}else{
    $divProduto = "display:none;";
}

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro</title>
    <link rel="stylesheet" href="cadastro.css">
</head>
<body>
    <header>
        <a href="index.html" class="logo">SK8 Creator</a>
        <a href="login.html" class="login-button">Sair</a>
    </header>
    <main>
        <div class='divProduto' style=" <?php echo"$divProduto"; ?>";>
            <p> <?php echo"$resposta"; ?> </p>
        </div>
        <p class="title">Cadastro de Produtos</p>
        <div class="content">
         
        <form action="cadastro.php" method="post">
            <label for="nome">Nome do Produto:</label>
            <input placeholder="Digite aqui o nome do produto" type="text" id="nome" name="nome" required>
    
            <label for="preco">Preço do Produto (R$):</label>
            <input placeholder="Digite aqui o preço do produto" type="number" id="preco" name="preco" step="0.01" required>

            <label for="size">Tamanho do Produto:</label>
            <input placeholder="Digite aqui o tamanho do produto" type="number" id="size" name="size" step="0.01">

            <label for="categoria">Categoria do Produto:</label>
            <select id="categoria" name="categoria" required>
                <option value="shape">Shape</option>
                <option value="truck">Truck</option>
                <option value="rodas">Rodas</option>
                <option value="rolamento">Rolamento</option>
                <option value="acessorios">Acessórios</option>
                <option value="acessorios">Outros</option>
            </select>
    
            <label for="imagem">Imagem do Produto (URL):</label>
            <input placeholder="Digite aqui a url da imagem do produto" type="url" id="imagem" name="imagem" required>
    
            <label for="descricao">Descrição do Produto:</label>
            <textarea placeholder="Digite aqui a descrição do produto" id="descricao" name="descricao" rows="4" cols="50" required></textarea>
    
            <input type="submit" value="Cadastrar">
    
        </form>
        <img class="skate-img" src="img/skate.png" alt="skate">
        </div>
  
    </main>
</body>
</html>